package com.example.voice101;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MapActivity extends AppCompatActivity {

    WebView Wv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        Wv = (WebView)findViewById(R.id.mapId);

        WebSettings webSettings = Wv.getSettings();
        Wv.getSettings().setLightTouchEnabled(true);
        Wv.getSettings().setJavaScriptEnabled(true);
        Wv.setWebViewClient(new WebViewClient());
        Wv.loadUrl("https://WWW.google.com/maps/");
    }
}
