package com.example.voice101;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegistrationPage extends AppCompatActivity {


  private  EditText new_name,new_email,new_phone,new_address,new_image,new_id,new_pass,new_user_type;
  private   RadioButton new_gender;
  private   Button signupbtn;

  DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);

        databaseReference = FirebaseDatabase.getInstance().getReference("userActivity");

        new_name = findViewById(R.id.user_nameId);
        new_phone = findViewById(R.id.user_phoneId);
        new_email = findViewById(R.id.user_emailId);
        new_address = findViewById(R.id.user_addressId);

        new_pass = findViewById(R.id.user_passId);
        new_user_type = findViewById(R.id.user_typeId);
        //new_image = findViewById(R.id.get_imageId);

        new_id = findViewById(R.id.userId_Id);




        //sign up process is here
        signupbtn = findViewById(R.id.loginId);
        signupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              String email = new_email.getText().toString().trim();
                String pass = new_pass.getText().toString().trim();
                String name = new_name.getText().toString().trim();
                String phone = new_phone.getText().toString().trim();
                String address = new_address.getText().toString().trim();
                String type = new_user_type.getText().toString().trim();

                String id = databaseReference.push().getKey();
                userActivity u = new userActivity(name,email,pass,phone,address,type);
                databaseReference.child(id).setValue(u);

                Toast.makeText(getApplicationContext(),"data successfuly added",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),LoginPage.class);
                startActivity(intent);
            }
        });

    }
}
