package com.example.voice101;

public class userActivity {
    String name;
    String email;
    String pass;
    String phone;
    String address;
    String type;

    public userActivity()
    {

    }

    public userActivity(String name, String email, String pass, String phone, String address, String type) {
        this.name = name;
        this.email = email;
        this.pass = pass;
        this.phone = phone;
        this.address = address;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPass() {
        return pass;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getType() {
        return type;
    }
}
