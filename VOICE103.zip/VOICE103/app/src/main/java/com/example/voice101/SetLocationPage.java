package com.example.voice101;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class SetLocationPage extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{


    private NavigationView navigationView;

    EditText cl,dl,cn;


    Button setbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_location_page);

        navigationView = findViewById(R.id.navBarId);
        navigationView.setNavigationItemSelectedListener(this);

        cl = findViewById(R.id.current_locationId);
        dl = findViewById(R.id.destination_locationId);
        cn = findViewById(R.id.car_numberId);

        setbtn = findViewById(R.id.getLocationId);
        setbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a,b,c;
                a = cl.getText().toString();
                b = dl.getText().toString();
                c = cn.getText().toString();
                Toast.makeText(getApplicationContext(),a+"\n"+b+"\n"+c,Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(),MapActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {


        if(menuItem.getGroupId()==R.id.contactID){
            Toast.makeText(this,"contact clicked",Toast.LENGTH_LONG).show();
        }
        else if(menuItem.getGroupId()==R.id.porfileID){
            Toast.makeText(this,"profile clicked",Toast.LENGTH_LONG).show();
        }

        else if(menuItem.getGroupId()==R.id.add_contactID){
            Toast.makeText(this,"profile clicked",Toast.LENGTH_LONG).show();
        }

        else if(menuItem.getGroupId()==R.id.privous_tripID){
            Toast.makeText(this,"previous trip clicked",Toast.LENGTH_LONG).show();
        }

        else if(menuItem.getGroupId()==R.id.LogOutID){
            Toast.makeText(this,"logout clicked",Toast.LENGTH_LONG).show();
        }
        else if(menuItem.getGroupId()==R.id.aboutD){
            Toast.makeText(this,"about clicked",Toast.LENGTH_LONG).show();
        }
        return false;
    }

}
